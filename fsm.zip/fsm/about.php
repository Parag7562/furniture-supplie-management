<?php
//connect to header file
include 'header.php';
?>

<!-- code for navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <?php
    if(isset($_SESSION["loggedin"]))
    {
      ?>
    <a class="navbar-brand" href="welcome.php">Back</a>
    <?php
    }
    else
    {
      ?>
    <a class="navbar-brand" href="index.php">Back</a>
      <?php
    }
    ?>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>

<!-- header photo-->
<div class="about-section mt-5" style="background-image: url(images/about/100.jpeg); height: 450px;text-align: justify;">
    <p style="font-size: 60px; margin-top: 40px;">Furniture Supply Management</p>

    <h4>Welcome to our furniture website! We are a team of passionate furniture experts who believe in providing the best quality furniture at affordable prices.
    We are committed to sustainable practices, and we believe that our responsibility extends beyond just producing furniture. We make sure that our suppliers follow ethical standards, use eco-friendly materials, and reduce waste wherever possible
    Customer satisfaction is our top priority. We strive to make every customer experience seamless, from browsing our website to receiving their furniture. Our customer service team is always ready to assist you with any questions or concerns.
    We hope that our furniture brings joy, comfort, and inspiration to your home. Thank you for choosing us as your furniture provider</h4>
</div>


<!-- Code for heading -->


<!-- Code for cards-->

<!--css for the about page-->
<style>
	body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  overflow-x: auto;
  overflow-y: auto;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 23.5%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;

}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
 
  }
}
h1{
	margin-top: 50px;
}
.row
{
	overflow-x: auto;
	overflow-y: auto;
}
.people
{
	overflow-x: hidden;
	overflow-y: hidden;
}
</style>
<?php
include 'footer.php';
?>