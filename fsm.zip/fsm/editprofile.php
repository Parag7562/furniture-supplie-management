<?php
//connect header file
include "header.php";
//if user not login then first login
if(!isset($_SESSION["loggedin"])){
  header('Location:login.php');
    exit;
 }
?>

<?php
$user_id = $_SESSION["user_id"];
?>
<!-- code for navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <?php
    if(isset($_SESSION["loggedin"]))
    {
      ?>
    <a class="navbar-brand" href="welcome.php">Back</a>
    <?php
    }
    else
    {
      ?>
    <a class="navbar-brand" href="index.php">Back</a>
      <?php
    }
    ?>  
</div>
</nav>

<?php
$change = false;
//query to update data of user
if(isset($_POST['submit']) == "Update")
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $contact = $_POST['contact'];
  $password = $_POST['password'];
  $address = $_POST['address'];

  $edit = "UPDATE `user` SET `name` = '$name', `email` = '$email', `contact` = '$contact', `password` = '$password', `address` = '$address' WHERE `user_id` =". $user_id;
  $result = mysqli_query($conn, $edit);
  if ($result == 1)
         {
           echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
           <strong>Succes!</strong> Your data has been updated.
           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
         }
         else
         {
           echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
           <strong>Fail!</strong> Your data has not been updated.
           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
         }
}

//query to display the data of user
$sql = "SELECT * FROM user where user_id = '".$user_id."'";
      $res = mysqli_query($conn, $sql);
      $name = "";
      $password = "";
      $email = "";
      $address = "";
      $contact = "";
      // code to fetch data
      while ($row = mysqli_fetch_array($res))
      {
        $name = $row['name'];
        $password = $row['password'];
        $email = $row['email'];
        $address = $row['address'];
        $contact = $row['contact'];
      }
?>

<!--heading -->
<h1 class="my-4" style="text-align: center;">Edit Profile</h1>
<style>
  .side_card
  {
    float:left; margin-right: 20px;
  }
</style>

<style>
  .container-fluid
  {
    overflow-y: hidden;
    overflow-x: hidden;
  }
</style>
  <!--form code from here-->
  <div class="container-fluid">
  <form method="POST" class="row g-3" style="margin-left: 230px;">
  <div class="col-md-5">
    <label for="name" class="form-label">Name</label>
    <input type="name" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
  </div>
  <div class="col-md-5">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>" required>
  </div>
  <div class="col-md-5">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password" value="<?php echo $password; ?>" required>
  </div>
  <div class="col-md-5">
    <label for="contact" class="form-label">Contact No</label>
    <input type="text" class="form-control" id="contact" name="contact" minlength="10" maxlength="10" value="<?php echo $contact; ?>" required>
  </div>
  <div class="col-md-10">
    <label for="address" class="form-label">Address</label>
    <input type="textarea" class="form-control" id="address" name="address" value="<?php echo $address; ?>" required>
  </div>
  <div class="col-12" style="margin-left: 400px; margin-top: 34px;">
    <button type="submit" class="btn btn-outline-success btn-lg" name="submit" id="submit" value="Update">Update</button>
  </div>
</form>
</div>

<?php
//connect footer file
include "footer.php";
?>