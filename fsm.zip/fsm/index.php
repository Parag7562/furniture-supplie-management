<?php
//connect to header file
include 'header.php';
//connect to navbar file
include 'navbar.php';
?>

<!--crasoul starts here-->
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/img/2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/img/3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!--heading -->
<h1 class="my-4" style="text-align: center;">Welcome to FSM.</h1>
<style>
  .side_card
  {
    float:left; margin-right: 20px;
  }
</style>
<!--cards starts from here-->
<?php
  //Query to display product 
	$sql = "SELECT * FROM `product`";
  $result = mysqli_query($conn, $sql);
  $p_id = 0;
  //code to display all products using while loop
  while($row = mysqli_fetch_assoc($result)){
    //storing database value in the variable to display the values
  $product_name = $row["product_name"];
  $price = $row["price"];
  $category = $row["category"];
  $description = $row["description"];
  $image = $row["image"];
?>

  <div class="card" style="width: 25rem; margin-left:25px; margin-bottom:25px; text-align:center;display:inline-block;">
  <div class="card h-80">
  <img class="card-img-top" src="admin/photo/product/<?php echo $image; ?>" alt="Card image cap" height="200" width="200" style="border-radius:.60rem;">
  <div class="card-block">
    <h4 class="card-title"><?php echo $product_name; ?></h4>
    <p class="card-text">Category : <span class="card-Category"><?php echo $category;?></span> </p>
    <p class="card-text">Price : <span class="card-price"><?php echo $price;echo " Rs"?></span> </p>
    <p class="card-text">Description : <span class="card-price"><?php echo $description;?></span> </p>
    <a class="btn btn-outline-primary" href="order.php?p_id=<?php echo $p_id; ?>" style="margin-bottom:20px" role="button">Buy</a>
  </div>
</div>
  </div>
  <?php
  $p_id = $p_id + 1;
  }
  ?>
  
  <?php
include 'footer.php';
?>