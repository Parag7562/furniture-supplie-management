<?php
include 'aheader.php';
if(!isset($_SESSION["loggedin"])){
    header('Location:index.php');
      exit;
   }
include 'anavbar.php';
include 'asidebar.php';
?>
<div class = "right_content">
      <h1> ADMIN PAGE OF FURNITURE SUPPLY MANGEMENT </h1>
      <style>
         h1
         {
            font-size: 100px;
            text-align: center;
            font-family: times;
         }
         </style>
      </div>  
<?php
include 'afooter.php';
?>
