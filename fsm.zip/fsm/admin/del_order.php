<?php
$update = false;
$delete = false;
//connect to header file
include "aheader.php";
if(!isset($_SESSION["loggedin"])){
  header('Location:index.php');
    exit;
 }
//connect to navabar file
include "anavbar.php";
//connect to sidebar file
include "asidebar.php";


//query to delete product from my product_order
if(isset($_POST['delete'])){
  $ord_id = $_POST['delete'];
 
  $sql = "DELETE FROM `product_order` WHERE `o_id` = $ord_id";
  $result = mysqli_query($conn, $sql);
  $delete = true;
}
?>

<!-- Heading code-->
<h1>Orders</h1>
<!--CSS for <h3> tag-->
<style>
    h1 {
        text-align: center;
        margin-top: 10px;
    }
</style>

<div class="right_content">
<?php
  if($delete){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong> Your data has been deleted successfully!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
  }
  ?>
<!-- Code to display data of user -->
<form action="" method="POST">
<table class="table table-success table-striped mt-2">
    <thead>
        <tr>
            <th scope="col">o_id</th>
            <th scope="col">p_id</th>
            <th scope="col">Name</th>
            <th scope="col">Email Id</th>
            <th scope="col">Mobile number</th>
            <th scope="col">Address</th>
            <th scope="col">Product Name</th>
            <th scope="col">Category</th>
            <th scope="col">Price</th>
            <th scope="col">Delivery</th>
            <th scope="col">Order Date</th>
            <th colspan="2" style="text-align:center;">Action</th>
        </tr>
    </thead>
    <tbody>
	    <?php 
            //Query to select the product that are delivered from product_order database and display
	          $sql = "SELECT * FROM `product_order` where delivery = 'delivered'";
	          $result = mysqli_query($conn, $sql);
	          $o_id = 0;
	          while($row = mysqli_fetch_assoc($result)){
                $or_id = $row["o_id"];
                $user_id = $row["user_id"];
                $p_id = $row["p_id"];
                $date = $row["date"];
                $delivery = $row["delivery"];
                //Query to display user detalis who ordered
                $select = "SELECT * FROM `user` where user_id =" . $user_id;
	          $res = mysqli_query($conn, $select);
	          while($roww = mysqli_fetch_assoc($res)){
                $name = $roww["name"];
                $email = $roww["email"];
                $contact = $roww["contact"];
                $address = $roww["address"];
                
                //Query which product is order
                $view = "SELECT * FROM `product` where p_id =" . $p_id;
                $show = mysqli_query($conn, $view);
                while($rrow = mysqli_fetch_assoc($show)){
                  $product_name = $rrow["product_name"];
                  $category = $rrow["category"];
                  $price = $rrow["price"];
                  $image = $rrow["image"];
                  

	            echo "<tr>	            
	            <td>". $or_id . "</td>
	            <td>". $p_id . "</td>
	            <td>". $name . "</td>
	            <td>". $email . "</td>
	            <td>". $contact . "</td>
	            <td>". $address . "</td>
                <td>". $product_name . "</td>
                <td>". $category . "</td>
                <td>". $price . " Rs</td>
                <td>". $delivery . "</td>
                <td>". $date . "</td>";
	            $or_id = $row['o_id'];
	            echo "<td> <button class='delete btn btn-sm btn-outline-primary' name='delete' id='delete' value='$or_id'>Delete</button></td>
	          </tr>";
              ?>
              <?php
                }
            }
              $o_id = $o_id + 1;
	        	} 
	    ?>
    </tbody>
</table>
</form>
</div>


<?php
//connect to footer file
include "afooter.php";
?>