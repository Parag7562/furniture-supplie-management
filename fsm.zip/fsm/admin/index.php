<?php
session_start();
include "config/db.php";
//Code to login 
$login = false;
$showError = false;
$email = "";
$password = "";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
  //Storing values of textbox in the variable  
    $email = $_POST["email"];
    $password = $_POST["password"];
        //Query to match the variable value in the database admin table value
        $sql = "Select * from admin where email ='$email' AND password='$password'";
        $result = mysqli_query($conn, $sql);
        $row = $result->fetch_assoc();
        $num = mysqli_num_rows($result);
        if ($num == 1)
        {
            $login = true;
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $row['email'];
            //value matched then headed to the admin page
            header("location: admin.php");
        } 
        else
        {
            $showError = "Invalid email or password";
        }
    }
?>

<?php
    if($login){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> You are logged in
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    
    ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <title>FSM ADMIN</title>
  </head>
  <body style="background: whitesmoke">
      <!-- logo -->
       <div class="text-center">
    <img src="images/logo/lg.png" class="img-fluid" alt="Responsive image">
  </div>
  <!-- navbar -->
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">FSM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
    </div>
  </div>
</nav>

<?php
      if($showError){
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      }
    ?>

<h1>LOG IN TO ADMIN</h1>
      <style>
        h1
        {
          margin-top: 30px;
          text-align: center;
        }
      </style>

      <!-- form -->
        <form method = "post" style="margin-top: 50px; margin-left: 500px;">
            <div class="form-group w-50 p-3 mx-4">
            <label for="email" style="font-size: 25px;">Email address</label>
            <input type="email" class="form-control" id="email" name = "email" aria-describedby="emailHelp">
            </div>
            
            <div class="form-group w-50 p-3 mx-4">
            <label for="password" style="font-size: 25px;">Password</label>
            <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn btn-outline-success btn-lg" style="margin-top:20px;margin-left:250px;">Log in</button>
        </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
  </body>
</html>