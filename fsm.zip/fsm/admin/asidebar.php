<div id="navigation bar"class="sidenav bg-dark sidenav-dark" data-color="light" data-mode="side" data-hidden="false"
    data-scroll-container="#scrollContainer"
    style="width: 205px; height:calc(100vh - 270px);position:sticky; transition: all 0.3s linear 0s; transform: translateX(0%);">
    <div id="scrollContainer" class="ps ps--active-y" style="max-height: calc(100% - 244px); position: sticky;">
      <ul class="sidenav-menu">
        <li class="nav-item" style="margin-left:-35px;">
                <a class="nav-link active" aria-current="page" href="aproduct.php">
                  <h6 style="color:white">Product</h6>
                </a>
              </li>
              <li class="nav-item" style="margin-left:-35px;">
                <a class="nav-link active" aria-current="page" href="pen_order.php">
                  <h6 style="color:white">Pending Orders</h6>
                </a>
              </li>
              <li class="nav-item" style="margin-left:-35px;">
                <a class="nav-link active" aria-current="page" href="del_order.php">
                  <h6 style="color:white">Delivered Orders</h6>
                </a>
              </li>
              <li class="nav-item" style="margin-left:-35px;">
                <a class="nav-link active" aria-current="page" href="#">
                  <h6 style="color:white">Payment</h6>
                </a>
              </li>
              <li class="nav-item" style="margin-left:-35px;">
                <a class="nav-link active" aria-current="page" href="a_user.php">
                  <h6 style="color:white">User</h6>
                </a>
              </li>
              <style>
                  .sidenav
                  {
                    float:left; margin-right:15px; margin-top:25px;
                  }
                  .right_content
                  {
                    height: calc(100vh - 280px);
                    overflow-y: auto;
                    overflow-x: auto;
                  }
              </style>
      </ul>
    </div>
</div>