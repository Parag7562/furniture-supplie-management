<?php
$delete = false;
//connect to header file
include 'aheader.php';
if(!isset($_SESSION["loggedin"])){
	header('Location:index.php');
	  exit;
   }
//connect to navabar file
include 'anavbar.php';
//connect to sidebar file
include 'asidebar.php';
?>
<div class="right_content">
<!-- Code to delete data -->
<?php
if(isset($_POST['delete'])){
  $p_id = $_POST['delete'];
  //query to delete data from product table in database
  $sql = "DELETE FROM `product` WHERE p_id =". $p_id;
  $result = mysqli_query($conn, $sql);
  $delete = true;
  if($delete){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
	<strong>Successful!</strong> Data deleted.
	<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
  }
}
?>
<h1>Manage products</h1>
<style>
	h1
	{
		text-align: center;
		margin-top: 40px;
	}
</style>
<a href="addproduct.php"><button type="button" class="btn btn-outline-danger btn-lg" style="margin-left:900px;">Add Products</button></a>

<!-- Code to display data of user -->
<form action="" method="POST">
<table class="table table-success table-striped mt-4">
    <thead>
        <tr>
            <th scope="col">p_id</th>
            <th scope="col">Product Name</th>
            <th scope="col">Category</th>
            <th scope="col">Description</th>
            <th scope="col">Image</th>
            <th scope="col">Price</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
	    <?php 
			  //Query to select product data from product table in database
	          $sql = "SELECT * FROM `product`";
	          $result = mysqli_query($conn, $sql);
	          $p_id = 0;
	          while($row = mysqli_fetch_assoc($result)){
	            $p_id = $p_id + 1;
	            echo "<tr>	            
	            <td>". $row['p_id'] . "</td>
	            <td>". $row['product_name'] . "</td>
	            <td>". $row['category'] . "</td>
	            <td>". $row['description'] . "</td>
	            <td>";
				?>
            <img style="width:100px; height:100px" src="Photo/product/<?php echo $row['image']; ?>" />
            <?php
				echo "</td>
	            <td>". $row['price'] . " Rs </td>";
	            $p_id = $row['p_id'];
	            echo " <td> <button class='delete btn btn-sm btn-outline-primary' name='delete' id='delete' value='$p_id'>Delete</button></td>
	          </tr>";
	        	} 
	    ?>
    </tbody>
</table>
</form>



</div>
<?php
//connect to footer file
include 'afooter.php';
?>