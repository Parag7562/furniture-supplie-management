<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "fsm";

global $conn;
//connecting to database
$conn = mysqli_connect($servername, $username, $password, $db);

function getDbConn(){
    global $conn;
    return $conn;
}

//function for inserting data into database 
function dbInsert($table, $values){
    $sql = "INSERT INTO ".$table." (".implode(", ", array_keys($values)).")
              VALUES ('".implode("', '", array_values($values))."');";
    
    $result = mysqli_query(getDbConn(), $sql);
    return mysqli_insert_id(getDbConn());
}

?>