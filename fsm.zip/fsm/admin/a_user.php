<?php
$delete = false;
//connect to header file
include "aheader.php";
if(!isset($_SESSION["loggedin"])){
  header('Location:index.php');
    exit;
 }
//connect to navabar file
include "anavbar.php";
//connect to sidebar file
include "asidebar.php";


?>
<!-- Query to delete data -->
<?php
if(isset($_POST['delete'])){
  $user_id = $_POST['delete'];
 //Query to delete user from user table in database
  $sql = "DELETE FROM `user` WHERE user_id =". $user_id;
  $result = mysqli_query($conn, $sql);
  $delete = true;
}
?>

<div class="right_content">
<!-- Code to display alert after the delete query-->
<?php
  if($delete){
    echo '<div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
    <strong>Successful!</strong> Data deleted.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
  }
  ?>
<!-- Heading code-->
<h1>Manage User Information</h1>
<!--CSS for <h3> tag-->
<style>
    h1 {
        text-align: center;
        margin-top: 10px;
    }
</style>

<!-- Code to display data of user -->
<form action="" method="POST">
<table class="table table-success table-striped mt-2">
    <thead>
        <tr>
            <th scope="col">user_id</th>
            <th scope="col">Name</th>
            <th scope="col">Email id</th>
            <th scope="col">Mobile number</th>
            <th scope="col">Password</th>
            <th scope="col">Address</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
	    <?php 
            //Query to select the user info from database and display
	          $sql = "SELECT * FROM `user`";
	          $result = mysqli_query($conn, $sql);
	          $user_id = 0;
	          while($row = mysqli_fetch_assoc($result)){
	            $user_id = $user_id + 1;
	            echo "<tr>	            
	            <td>". $row['user_id'] . "</td>
	            <td>". $row['name'] . "</td>
	            <td>". $row['email'] . "</td>
	            <td>". $row['contact'] . "</td>
	            <td>". $row['password'] . "</td>
	            <td>". $row['address'] . "</td>";
	            $user_id = $row['user_id'];
	            echo " <td> <button class='delete btn btn-sm btn-outline-primary' name='delete' id='delete' value='$user_id'>Delete</button></td>
	          </tr>";
	        	} 
	    ?>
    </tbody>
</table>
</form>
</div>

<?php
include "afooter.php";
?>