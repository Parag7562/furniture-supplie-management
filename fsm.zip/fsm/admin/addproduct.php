<?php

//connect to header
include 'aheader.php';
if(!isset($_SESSION["loggedin"])){
  header('Location:index.php');
    exit;
 }
?>

<!-- code for navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="aproduct.php">Back</a>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>

<!-- Code to insert data in product table in database -->
<?php
$conn = getDbConn();
if (isset($_POST["submit"]) == "insert"){
    //storing image value in the database and move the photo to photo/product/ folder 
    $fileName = time().'-'.$_FILES['image']['name'];
    $status = move_uploaded_file($_FILES['image']['tmp_name'], 'Photo/product/'.$fileName);
    //Query to insert data in product table
    $query = dbInsert('product', [
      'product_name' => $_POST["product_name"],
      'category' => $_POST["category"],
      'description' => $_POST["description"],
      'price' => $_POST["price"],
      'image' => $fileName,
    ]);


    if($query){
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Successful!</strong> Your data is inserted.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    } 
    else {
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Error!</strong> Enter details properly.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
  }
?>
<!-- code for heading -->
<h1>ADD PRODUCT TO FSM</h1>
<style>
	h1
	{
		text-align: center;
		color: black;
		margin-top: 10px;
	}
</style>

<style>
  
  .container-fluid
  {
    overflow-y: hidden;
    overflow-x: hidden;
  }
</style>
<div class="container-fluid">
<!-- code to enter details of product -->
<form method="POST" enctype="multipart/form-data" action="" class="row g-3" style="margin-top: 25px; margin-left: 250px;">
  <div class="col-md-5">
    <label for="product_name" class="form-label">Product Name</label>
    <input type="text" class="form-control" id="product_name" name="product_name" required>
  </div>
  <div class="col-md-5">
    <label for="price" class="form-label">Product Price</label>
    <input type="text" class="form-control" id="price" name="price" required>
  </div>
  <div class="col-5">
    <label for="description" class="form-label">Description</label>
    <input type="text" class="form-control" id="description" name="description" required placeholder="Double Bed">
  </div>
  <div class="col-md-5">
    <label for="category" class="form-label">Category</label>
    <select id="category" name="category" class="form-select" required>
      <option selected>Choose...</option>
      <option value="chair" name="category" id="option_1">Chair</option>
      <option value="sofa" name="category" id="option_2">Sofa</option>
      <option value="bed" name="category" id="option_3">Bed</option>
      <option value="table" name="category" id="option_4">Table</option>
    </select>
  </div>
        <div class="text" style="margin-top: 50px;">
        	 <label for="image" class="form-label">Product Image:</label>
          <input type="file" id="image" name="image" class="my_file" required/> 
        </div>
  <div class="col-12">
    <button type="submit" name="submit" id="submit" value="insert" class="btn btn-outline-danger" style="margin-top: 10px;margin-left: 450px;">ADD</button>
  </div>
</form>
</div>
<?php
include 'afooter.php';
?>