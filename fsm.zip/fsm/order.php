<?php
//connect to header file
include 'header.php';
//if user not login then first login
if(!isset($_SESSION["loggedin"])){
  header('Location:login.php');
    exit;
 }
$conn = getDbConn();

?>
<?php
    $p_id = $_GET["p_id"];
    $user_id = $_SESSION["user_id"];
    $dt = date('Y-m-d');
   
?>

<!-- code for navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="product.php">Back</a>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>

<!-- Code to insert data in product table in database -->
<?php
//query to insert the data of the product ordered by user 
if (isset($_POST["submit"]) == "buy"){
  $query = dbInsert('product_order', [
      'user_id' => $user_id,
      'p_id' => $p_id,
      'date' => $dt, 
      'delivery' => "pending",     
    ]);

    if($query){
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Successful!</strong> Your order is placed.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    } 
    else {
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Error!</strong> Enter details properly.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
  }
?>

<!-- code for heading -->
<h1>PLACE ORDER</h1>
<style>
	h1
	{
		text-align: center;
		color: black;
		margin-top: 20px;
	}
</style>

<style>
  
  .container-fluid
  {
    overflow-y: hidden;
    overflow-x: hidden;
  }
</style>
<div class="container-fluid">
<!-- code to enter details of product -->
<form method="POST" action="" class="row g-3" style="margin-top: 22px; margin-left: 250px;">
  <!-- Product name -->
  <!-- code to diplay the detail of product -->
  <?php
  //query to display product details
  $p_id = $_GET["p_id"];
   $sql = "SELECT * FROM `product` where p_id = ".$p_id;
   $result = mysqli_query($conn, $sql);
   while($row = mysqli_fetch_assoc($result)){
     $product_name = $row["product_name"];
     $category = $row["category"];
     $description = $row["description"];
     $price = $row["price"];
  ?>
  <div class="col-md-5">
    <label for="product_name" class="form-label">Product Name</label>
    <input class="form-control" id="product_name" name="product_name" value= "<?php echo $product_name; ?>" disabled>
  </div>

  <!-- category -->
  <div class="col-md-5">
    <label for="category" class="form-label">Category</label>
    <input type="text" class="form-control" id="category" name="category" value= "<?php echo $category; ?>" disabled>
  </div>

  <!-- description -->
  <div class="col-5">
    <label for="description" class="form-label">Description</label>
    <input type="text" class="form-control" id="description" name="description" value= "<?php echo $description; ?>" disabled>
  </div>

  <!-- price -->
  <div class="col-md-5">
    <label for="price" class="form-label">Product Price</label>
    <input type="number" class="form-control" id="price" name="price" value= "<?php echo $price; ?>" disabled>
  </div>
 

  <!-- total_amount -->
  <div class="col-md-5">
    <label for="total_amount" class="form-label">Total Amount</label>
    <input type="number" class="form-control" id="total_amount" name="total_amount" value="<?php echo $price; ?>" disabled>
  </div>

  <!-- Button -->
  <div class="col-12">
    <button type="submit" name="submit" id="submit" value="buy" class="btn btn-outline-primary" style="margin-top: 10px;margin-left: 400px;">BUY</button>
  </div>
</form>
</div>
<?php
   }
   ?>
<?php
//connect to footer file
include 'footer.php';
?>