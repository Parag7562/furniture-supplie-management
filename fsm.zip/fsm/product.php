<?php
//connect to header file
include "header.php";
?>
<!-- code for navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <?php
    if(isset($_SESSION["loggedin"]))
    {
      ?>
    <a class="navbar-brand" href="welcome.php">Back</a>
    <?php
    }
    else
    {
      ?>
    <a class="navbar-brand" href="index.php">Back</a>
      <?php
    }
    ?>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>
<!--heading -->
<h1 class="my-4" style="text-align: center;">Products</h1>
<style>
  .side_card
  {
    float:left; margin-right: 20px;
  }
</style>
<!--cards starts from here-->
<?php
  //Query to display product 
	$sql = "SELECT * FROM `product`";
  $result = mysqli_query($conn, $sql);
  $p_id = 0;
  //code to display all products using while loop
  while($row = mysqli_fetch_assoc($result)){
    //storing database value in the variable to display the values
  $p_id = $row["p_id"];
  $product_name = $row["product_name"];
  $price = $row["price"];
  $category = $row["category"];
  $description = $row["description"];
  $image = $row["image"];
?>

  <div class="card mb-10" style="margin: 25px 25px  25px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="admin/photo/product/<?php echo $image; ?>" alt="..." height="280" width="440" style="border-radius:.60rem;">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h4 class="card-title"><?php echo $product_name; ?></h4>
        <p class="card-text">Category : <span class="card-Category"><?php echo $category;?></span> </p>
        <p class="card-text">Price : <span class="card-price"><?php echo $price; echo" Rs";?></span> </p>
        <p class="card-text">Description : <span class="card-price"><?php echo $description;?></span> </p><br>
        <a class="btn btn-outline-primary" href="order.php?p_id=<?php echo $p_id; ?>" style="margin-bottom:20px; margin-left:100px;" role="button">Buy</a>
      </div>
    </div>
  </div>
</div>
  <?php
  $p_id = $p_id + 1;
  }
  ?>


<?php
//connect to footer file
include "footer.php";
?>