<?php
//connect to header
include "header.php";
//if user is not login then login first
if(!isset($_SESSION["loggedin"])){
    header('Location:login.php');
      exit;
   }
?>

<?php
$user_id = $_SESSION["user_id"];
?>
<!-- code for navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <?php
    if(isset($_SESSION["loggedin"]))
    {
      ?>
    <a class="navbar-brand" href="welcome.php">Back</a>
    <?php
    }
    else
    {
      ?>
    <a class="navbar-brand" href="index.php">Back</a>
      <?php
    }
    ?>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>
<!--heading -->
<h1 class="my-4" style="text-align: center;">Ordered Products</h1>
<style>
  .side_card
  {
    float:left; margin-right: 20px;
  }
</style>

<!-- Code to cancel order -->
<?php
if(isset($_POST['delete'])){
  $ord_id = $_POST['delete'];
 
  $sql = "DELETE FROM `product_order` WHERE `o_id` = $ord_id";
  $result = mysqli_query($conn, $sql);
  $delete = true;
  if($delete){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong> Your data has been deleted successfully!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
  }
}
?>
<?php
//query to display order
$sql = "SELECT * FROM `product_order` where user_id = " .$user_id;
  $result = mysqli_query($conn, $sql);
  $o_id = 0;
  while($row = mysqli_fetch_assoc($result)){
      $or_id = $row["o_id"];
      $p_id = $row["p_id"];
      $date = $row["date"];
      $delivery = $row["delivery"];

      //query to display product details about order product
      $select = "SELECT * FROM `product` where p_id = " .$p_id;
      $res = mysqli_query($conn, $select);
      $p_id = 0;
      while($row = mysqli_fetch_assoc($res)){ 
          $product_name = $row["product_name"];
          $category = $row["category"];
          $image = $row["image"];
          $price = $row["price"];
?>
<form method="POST" action="">
<div class="card mb-10" style="margin: 25px 25px  25px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="admin/photo/product/<?php echo $image; ?>" alt="..." height="300" width="440" style="border-radius:.60rem;">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h4 class="card-title"><?php echo $product_name; ?></h4>
        <p class="card-text">Order Id : <span class="card-price"><?php echo $or_id;?></span> </p>
        <p class="card-text">Category : <span class="card-Category"><?php echo $category;?></span> </p>
        <p class="card-text">Price : <span class="card-price"><?php echo $price; echo" Rs"?></span> </p>
        <p class="card-text">Ordered Date : <span class="card-price"><?php echo $date;?></span> </p>
        <p class="card-text">Delivery status : <span class="card-price"><?php echo $delivery;?></span> </p>
        <?php
          echo "<button style='margin-left:80px' class='delete btn btn-sm btn-outline-primary' name='delete' id='delete' value='$or_id'>Cancel order</button>";
        ?>
      </div>
    </div>
  </div>
</div>
</form>

<?php
$p_id = $p_id + 1;
 }
?>
<?php
$o_id = $o_id + 1;
  }
  ?>


<?php
//connect footer file
include "footer.php";
?>
