<?php
//connect to header file
include 'header.php';
if(!isset($_SESSION["loggedin"])){
  header('Location:login.php');
    exit;
 }
?>
<?php
    $p_id = $_GET["p_id"];
    $user_id = $_SESSION["user_id"];
    $dt = date('Y-m-d');
   
?>

<!-- code for navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="product.php">Back</a>  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
  </div>
</div>
</nav>

<!-- Code to insert data in product table in database -->
<?php
$conn = getDbConn();
if (isset($_POST["submit"]) == "buy"){
    //Query to insert data in product table
    $query = dbInsert('product', [
      'user_id' => $user_id,
      'p_id' => $p_id, 
      'date' => $dt, 

    ]);


    if($query){
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Successful!</strong> Your data is inserted.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    } 
    else {
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Error!</strong> Enter details properly.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
  }
?>

<!-- code for heading -->
<h1>PLACE ORDER</h1>
<style>
	h1
	{
		text-align: center;
		color: black;
		margin-top: 20px;
	}
</style>

<style>
  
  .container-fluid
  {
    overflow-y: hidden;
    overflow-x: hidden;
  }
</style>
<div class="container-fluid">
<!-- code to enter details of product -->
<form method="POST" action="" class="row g-3" style="margin-top: 22px; margin-left: 250px;">
 
  <!-- Button -->
  <div class="col-12">
    <button type="submit" name="submit" id="submit" value="buy" class="btn btn-outline-primary" style="margin-top: 10px;margin-left: 400px;">BUY</button>
  </div>

</form>
</div>


<?php
include 'footer.php';
?>
