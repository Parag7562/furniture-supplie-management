<footer class="text-center text-white" id = "footer"style="background-color: #212529;top: 100%;position: sticky; ">
  <!-- Grid container -->
  
  <div class="text-center text-light p-3" style="font-size:30px;margin-top:25px;position: sticky;top: 100%">
    Thanks for Visting FSM!
  </div>
  
  </body>
</html>